# 🕹️ Playtime Co. — Multiplayer Setup Guide

## What you have

| File | Purpose |
|---|---|
| `playtime_enhanced.html` | Your game — already has the multiplayer client built in |
| `server.js` | The WebSocket relay server |
| `package.json` | Node.js config |
| `fly.toml` | Fly.io deployment config |

---

## Step 1 — Install the Fly.io CLI

Open a terminal and run:

```bash
# macOS
brew install flyctl

# Windows (PowerShell)
powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"

# Linux
curl -L https://fly.io/install.sh | sh
```

Then sign up / log in:

```bash
fly auth signup     # first time
# OR
fly auth login      # already have an account
```

---

## Step 2 — Put your server files in a folder

Create a folder called `playtime-server` and put these three files in it:

```
playtime-server/
  server.js
  package.json
  fly.toml
```

---

## Step 3 — Choose your app name

Open `fly.toml` and change line 4:

```toml
app = "playtime-party"   ← change this to something unique
```

The name becomes part of your URL: `wss://YOUR-APP-NAME.fly.dev`

Good names: `playtime-party-yourname`, `huggy-server`, `ptco-online`

---

## Step 4 — Deploy

```bash
cd playtime-server

fly launch --no-deploy   # reads fly.toml, creates the app
fly deploy               # builds and deploys — takes ~60 seconds
```

You'll see output like:
```
✓ Machine started
Visit your app at https://playtime-party.fly.dev
```

Your WebSocket server is now live at:
```
wss://playtime-party.fly.dev
```

---

## Step 5 — Point your game at the server

Open `playtime_enhanced.html` in a text editor.

Find this line (around line 1700):

```javascript
const SERVER_URL = 'wss://playtime-party.fly.dev';
```

Change `playtime-party` to your actual app name:

```javascript
const SERVER_URL = 'wss://YOUR-APP-NAME.fly.dev';
```

Save the file. That's it — the game is ready.

---

## Step 6 — Play with friends

1. Open `playtime_enhanced.html` in Chrome/Edge (not Firefox — it blocks local file WebSockets)
2. Click the **⬡ PARTY** button in the top-right corner
3. **To host:** type your name → click **CREATE PARTY** → share the 4-letter code
4. **To join:** type your name → click **JOIN PARTY** → enter the code → press Join
5. Press **T** to chat in-game

Friends can host the HTML file themselves or you can put it on GitHub Pages / any static host.

---

## Useful fly.io commands

```bash
fly status              # check if server is running
fly logs                # see live server logs (connections, party events)
fly deploy              # push an update to server.js
fly scale count 1       # make sure 1 machine is always running
fly machine list        # see all machines
```

---

## Troubleshooting

**"Connection failed" in game**
- Check `fly logs` for errors
- Make sure the SERVER_URL in the HTML matches your actual app name exactly
- Try `fly status` — machine should say `started`

**Friends can't connect**
- The game HTML must be served over HTTPS or `file://` with the `wss://` URL
- If hosting on GitHub Pages (HTTPS), `wss://` works fine
- If running from `file://` locally, most browsers allow `wss://` connections

**Party code not found**
- Codes are case-insensitive (the client uppercases automatically)
- Parties dissolve when everyone leaves — host must create a new one

**Server goes to sleep**
- Free Fly.io machines can spin down after inactivity
- The `fly.toml` already sets `auto_stop_machines = false` and `min_machines_running = 1`
- First connection after idle may take 3-5 seconds to wake

---

## How the system works

```
Player A (host)                     Fly.io Server                    Player B
────────────────                    ─────────────                    ────────
click "Create Party"   →  { type:'create', name:'A' }  →           
                       ←  { type:'welcome', code:'XKQP' }  ←       
share code "XKQP"                                                   
                                                        click "Join Party"
                       →  { type:'join', code:'XKQP' }  ←          
                       →  { type:'welcome', players:[A] } →  ←      
                       →  { type:'joined', id:A, name:'A' } →       

Every 50ms:
A's position    →  { type:'state', x,y,z,yaw }  →  broadcast to B
B sees A ghost mesh rendered at A's coordinates

B's position    →  { type:'state', x,y,z,yaw }  →  broadcast to A
A sees B ghost mesh
```

---

## What multiplayer does in-game

- **Other players** appear as colored ghost figures with their name floating above
- **Name tags** rendered on screen in their party color
- **Chat** — press T to type a message, appears as floating text for 6 seconds
- **Party code** shown in top-right button once connected
- Up to **8 players** per party
- Each party is **isolated** — other parties can't see or interfere with you
